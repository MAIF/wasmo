export function execute() {
    Host.outputString(JSON.stringify({
        active: true
    }));

    return 0;
}